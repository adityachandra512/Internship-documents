from django.shortcuts import render
from .forms import StudentRegistration

def showformdata(request):
    if request.method == 'POST':
        fm = StudentRegistration(request.POST)
        if fm.is_valid():
            nm = fm.cleaned_data['name']
            em = fm.cleaned_data['email']
            pw = fm.cleaned_data['password']
            print(nm)
            print(em)
            print(pw)
            # You can add more logic here like saving the data to the database
    else:
        fm = StudentRegistration()
    
    return render(request, 'enroll/userregistration.html', {'form': fm})
