from django.core import validators
from django import forms
from .models import User

class StudentRegistration(forms.ModelForm):
    class Meta:
        model=User
        fields = ['name','email','password']
        labels = {'name':'Enter name','password':'Enter password','email':'Enter email'}
        error_messages = {
            'name':{'required':'Pl write your name'}, 
            'email':{'required':'Pl enter your Email'},
            'password':{'required':'Pl enter your password'}
            }
        widgets = {
            'password':forms.PasswordInput,
            'name':forms.TextInput(attrs={'class':'myclass','placeholder':'name'})
        }