from django.shortcuts import render
from datetime import datetime
# Create your views here.
def learn_django(request):
    stu = {'stu1':{'name':'Rahul', 'roll':101},
    'stu2': {'name' : 'sonam','roll':102},
    'stu3': {'name' : 'Raj','roll':103},
    'stu4': {'name' : 'Anu','roll':104},
    }
    students ={'student':stu}
    return render(request,'course/courseone.html',students)
