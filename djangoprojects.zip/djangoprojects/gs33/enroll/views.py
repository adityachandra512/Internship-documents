from django.shortcuts import render
from .forms import StudentRegistration
from .models import user
# Create your views here.
def showformdata(request):
    if request.method == 'POST':
        fm=StudentRegistration(request.POST)
        if fm.is_valid():
            nm=fm.cleaned_data['name']
            em=fm.cleaned_data['email']
            pw=fm.cleaned_data['password']
           # reg=user(name=nm,email=em,password=pw)
            reg=user(id=1)
            reg.delete()
    else:
        fm=StudentRegistration()
        print('ya get request sa aya hai')
    return render(request,'enroll/userregistration.html',{'form':fm})