from django.shortcuts import render
from .forms import studentRegistration
from django.contrib import messages
# Create your views here.
def regi(request):
    if request.method=="POST":
        fm=studentRegistration(request.POST)
        if fm.is_valid():
            fm.save()
            messages.add_message(request,messages.INFO,'your account has been created')
            messages.info(request,'now you can login')
    else:        
     fm= studentRegistration()
    return render(request,'enroll/userregistration.html',{'form':fm})