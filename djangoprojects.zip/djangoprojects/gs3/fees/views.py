from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def feeses(request):
    return HttpResponse('300')
