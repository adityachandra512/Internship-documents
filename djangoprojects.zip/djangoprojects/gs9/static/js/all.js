function display(){
    alert("i am using js")
}