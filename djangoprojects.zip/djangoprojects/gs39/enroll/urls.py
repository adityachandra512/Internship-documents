from django.urls import path, register_converter
from . import views, converter

# Register the custom converter
register_converter(converter.fourdigitalyearconverter, 'yyyy')

urlpatterns = [
    path('<yyyy:year>/', views.show_details, name="detail"),
]
