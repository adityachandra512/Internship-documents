from django.core import validators
from django import forms
class StudentRegistration(forms.Form):
    name=forms.CharField()
    email=forms.EmailField()
    password=forms.CharField(widget=forms.PasswordInput)
    repassword=forms.CharField(label='password(again)',widget=forms.PasswordInput)
    
    def clean(self):
        cleaned_data = super().clean()
        valwd = self.cleaned_data['password']
        valrewd = self.cleaned_data['repassword']
        if valwd != valrewd :
            raise forms.ValidationError('the password is not matched pl try again')