from django import forms
class StudentRegistration(forms.Form):
    name=forms.CharField(label="your name",label_suffix=' ',initial="sonam",disabled=True)