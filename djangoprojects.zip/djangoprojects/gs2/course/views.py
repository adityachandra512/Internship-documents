from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def homepage(request):
    return HttpResponse('<h1>home page</h1>')

def learn_django(request):
    return HttpResponse('hello world')

def learn_variable(request):
    a=10
    return HttpResponse(a)

def learn_html(request):
    return HttpResponse('<h1> hello world </h1>')

def learn_fromat(request):
    a='aditya'
    return HttpResponse(f'hello my name is {a}')