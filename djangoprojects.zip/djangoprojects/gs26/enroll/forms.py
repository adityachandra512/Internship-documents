from django import forms
class StudentRegistration(forms.Form):
    name=forms.CharField(min_length=5,max_length=10,strip=False,empty_value='somnam',error_messages={'required':'Enter your name'})
    roll=forms.IntegerField()
    price=forms.DecimalField(min_value=5,max_value=40,max_digits=4,decimal_places=2)
    rate=forms.FloatField(min_value=5,max_value=40)
    agree=forms.BooleanField(label='i agree',label_suffix=' ')